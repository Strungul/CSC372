/**
 * 
 */
/**
 * 
 */
module CSC272_Module3_Critical_Thinking {
	requires javafx.controls;
	requires javafx.fxml;
	exports creating_a_User_Interface_1;
	
}