/**
 * 
 */
/**
 * 
 */
module CSC372_Module2_Critical_Thinking {
	requires java.desktop;
}